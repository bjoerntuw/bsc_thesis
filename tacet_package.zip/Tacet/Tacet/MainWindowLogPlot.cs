﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using Tacet.Handlers;
using Tacet.DAO;
using Microsoft.Research.DynamicDataDisplay;
using Microsoft.Research.DynamicDataDisplay.DataSources;
using Microsoft.Research.DynamicDataDisplay.PointMarkers;
using System.Collections.ObjectModel;
using Tacet.Helpers;
namespace Tacet
{


    /**

	Tacet - A smart symptoms diary for people suffering from Tinnitus.
    Copyright (C) 2014,  Bernhard Brenner <bernhard.brenner@student.tuwien.ac.at>

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.

*/


    /**
     * Here is everything about plotting the collected data to a chart.
     * 
     * 
     */
    public partial class Main : Window
    {
        List<Datagram> dList;

        private void plotDatagrams(List<Datagram> dList)
        {
            List<DateTime> dateList=new List<DateTime>();
            List<Double> symptomList = new List<Double>();

            foreach (Datagram d in dList)
            {
                DateTime dateOnly = d.Timestamp;
                Double value = d.SymptomValue;
                
                dateList.Add(dateOnly);
                symptomList.Add(value);

                //fehlerMeldung(dateOnly.ToString() + "::" +value);

            }

            graph(dateList, symptomList);
        }

        private EnumerableDataSource<DateTime> datesDataSource;
        private EnumerableDataSource<Double> symptomValueDataSource;


        private void graph(List<DateTime> dateList, List<Double> symptomList)
        {
     
            try
            {
                if (dateList == null)
                    return;
                logger.DEBUG("Plotting a graph of " + dateList.Count + " Datagrams");
                datesDataSource = new EnumerableDataSource<DateTime>(dateList);
                datesDataSource.SetXMapping(x => dateAxis.ConvertToDouble(x));

                symptomValueDataSource = new EnumerableDataSource<Double>(symptomList);
                symptomValueDataSource.SetYMapping(y => y);


                CompositeDataSource compositeDataSource1 = new
                CompositeDataSource(datesDataSource, symptomValueDataSource);
          

                plotter.AddLineGraph(compositeDataSource1,
                   new Pen(Brushes.Blue, 2),
                   new CirclePointMarker { Size = 3.0, Fill = Brushes.Red },
                   new PenDescription("TT-Verlauf"));
            }
            catch (InvalidCastException e)
            {
                fehlerMeldung("Failed to Plot:Got Invalid Cast Exception:" + e.Message);
            }
          
            plotter.Viewport.FitToView();

        }

        private void plotFactor(List<Datagram> dList, int factor, Pen colour, CirclePointMarker marker, string description)
        {
            List<DateTime> dateList = new List<DateTime>();
            List<Double> symptomList = new List<Double>();

            foreach (Datagram d in dList)
            {
                DateTime dateOnly = d.Timestamp;
                Double value = d.Factors.ElementAt(factor-1).Value;

                dateList.Add(dateOnly);
                symptomList.Add(value);

                //fehlerMeldung(dateOnly.ToString() + "::" +value);

            }

            /* Red- Blue
             * Green - Magenta
             * Magenta - Green
             * Blue - Red
             * Yellow - Black
             * Black - Yellow
             * 
             */

            graphColour(dateList, symptomList,colour, marker, description);
        }


        private void graphColour(List<DateTime> dateList, List<Double> symptomList, Pen colour, CirclePointMarker marker, string description)
        {

            try
            {
                logger.DEBUG("Plotting a graph of " + dateList.Count + " Datagrams");
                datesDataSource = new EnumerableDataSource<DateTime>(dateList);
                datesDataSource.SetXMapping(x => dateAxis.ConvertToDouble(x));

                symptomValueDataSource = new EnumerableDataSource<Double>(symptomList);
                symptomValueDataSource.SetYMapping(y => y);


                CompositeDataSource compositeDataSource1 = new
                CompositeDataSource(datesDataSource, symptomValueDataSource);


                plotter.AddLineGraph(compositeDataSource1,
                   colour,
                   marker,
                   new PenDescription(description));
            }
            catch (InvalidCastException e)
            {
                fehlerMeldung("Failed to Plot:Got Invalid Cast Exception:" + e.Message);
            }

            plotter.Viewport.FitToView();

        }


        private void plotGraphAfterStart()
        {
            if (datenAnsichtEmpty())
            {
                return;
            }


            dList = new List<Datagram>();
            //attention: i begins to count with one, because the first line is the header line!
            for (int i = 1; i < datenAnsicht.Items.Count; ++i)
            {
                String line = datenAnsicht.Items.GetItemAt(i).ToString();
                Datagram d = DatagramProcessor.stringToDatagram(line);

                dList.Add(d);
            }

            plotDatagrams(dList);
        }


        private void plotGraph()
        {
            if (datenAnsichtEmpty())
            {
                fehlerMeldung("Noch keine Daten vorhanden.");
                return;
            }


            dList = new List<Datagram>();
            //attention: i begins to count with one, because the first line is the header line!
            for (int i = 1; i < datenAnsicht.Items.Count; ++i)
            {
                String line = datenAnsicht.Items.GetItemAt(i).ToString();
                Datagram d = DatagramProcessor.stringToDatagram(line);

                dList.Add(d);
            }

            plotDatagrams(dList);
        }

         private void bReset_Click(object sender, RoutedEventArgs e)
        {
            clearLogPlotLines();
            if(factorCount>=1)
                cFaktor1.IsEnabled = true;
            if (factorCount >= 2)
                cFaktor2.IsEnabled = true;
            else
            {
                cFaktor2.Visibility = Visibility.Hidden;
                
            }
            if (factorCount >= 3)
                cFaktor3.IsEnabled = true;
            else
            {
                cFaktor3.Visibility = Visibility.Hidden;
            }

            cFaktor1.IsChecked = false;
            cFaktor2.IsChecked = false;
            cFaktor3.IsChecked = false;


            //regBeschriftungX.Content = "X";
            //regBeschriftungY.Content = "Y";
            plotGraph();
        }


         private void cFaktor1_Checked(object sender, RoutedEventArgs e)
         {
             if (dList==null)
             {
                 fehlerMeldung("Noch keine Daten vorhanden!");
                 cFaktor1.IsChecked = false;
                 return;
             }


             plotFactor(dList, 1, new Pen(Brushes.Green, 2), new CirclePointMarker { Size = 3.0, Fill = Brushes.Magenta }, factorOneName);

             cFaktor1.IsEnabled=false;
         }

         private void cFaktor2_Checked(object sender, RoutedEventArgs e)
         {
             if (dList == null)
             {
                 fehlerMeldung("Sie müssen erst auf \"Plotten\" klicken!");
                 cFaktor2.IsChecked = false;
                 return;
             }


             plotFactor(dList, 2, new Pen(Brushes.Gold, 2), new CirclePointMarker { Size = 3.0, Fill = Brushes.LightCyan }, factorTwoName);
             cFaktor2.IsEnabled = false;
         }

         private void cFaktor3_Checked(object sender, RoutedEventArgs e)
         {
             if (dList == null)
             {
                 fehlerMeldung("Sie müssen erst auf \"Plotten\" klicken!");
                 cFaktor3.IsChecked = false;
                 return;
             }


             plotFactor(dList, 3, new Pen(Brushes.SaddleBrown, 2), new CirclePointMarker { Size = 3.0, Fill = Brushes.Green }, factorThreeName);
             cFaktor3.IsEnabled = false;
         }


         /**
          * Removes the Lines and Scatters, which are already plotted.
          * 
          * 
          */
         private void clearLogPlotLines()
         {
             Collection<IPlotterElement> clearList = new Collection<IPlotterElement>();
             foreach (var x in plotter.Children)
             {
                 if (x is LineGraph || x is ElementMarkerPointsGraph || x is MarkerPointsGraph)
                     clearList.Add(x);
             }

             foreach (IPlotterElement x in clearList)
             {
                 plotter.Children.Remove(x);
             }
         }


    }
}
