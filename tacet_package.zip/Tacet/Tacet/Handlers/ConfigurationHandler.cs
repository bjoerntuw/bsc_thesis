﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Configuration;

namespace Tacet
{

    /**

	Tacet - A smart symptoms diary for people suffering from Tinnitus.
    Copyright (C) 2014,  Bernhard Brenner <bernhard.brenner@student.tuwien.ac.at>

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.

*/
    class ConfigurationHandler
    {
        //private LoggingHandler logger = null;
        private string configpath;
        Configuration config = null;
        /**
         * This Class handles the Configuration file.
         * Writing and Reading.
         * 
         * 
         */

        /**
         * Constructor
         * 
         * 
         * @path The Path to the Configuration file.
         */
        public ConfigurationHandler(string path)
        {
           
            this.configpath = path;

            //config = ConfigurationManager.OpenExeConfiguration(configpath);
            ExeConfigurationFileMap map = new ExeConfigurationFileMap { ExeConfigFilename = configpath };
            config = ConfigurationManager.OpenMappedExeConfiguration(map, ConfigurationUserLevel.None);
        }

        public string getConfigString(string key)
        {
            
            return config.AppSettings.Settings[key].Value;
        }

        public void setConfigString(string key, string value)
        {
            if (config.AppSettings.Settings[key] != null)
            {
                config.AppSettings.Settings.Remove(key);
            }

            config.AppSettings.Settings.Add(key, value);
            config.Save(ConfigurationSaveMode.Modified);

        }
    }
}
