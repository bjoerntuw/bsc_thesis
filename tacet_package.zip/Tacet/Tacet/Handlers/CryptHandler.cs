﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Org.BouncyCastle.Crypto;
using Org.BouncyCastle.Crypto.Generators;
using Org.BouncyCastle.Security;
using Org.BouncyCastle.Crypto.Engines;
using Org.BouncyCastle.Asn1.Pkcs;
using Org.BouncyCastle.Pkcs;
using Org.BouncyCastle.Asn1.X509;
using Org.BouncyCastle.X509;
using Org.BouncyCastle.Crypto.Parameters;
using System.Security.Cryptography;
using Org.BouncyCastle.Crypto.Encodings;
using Org.BouncyCastle.Crypto.Digests;

namespace Tacet.Handlers
{

    /**

	Tacet - A smart symptoms diary for people suffering from Tinnitus.
    Copyright (C) 2014,  Bernhard Brenner <bernhard.brenner@student.tuwien.ac.at>

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.

*/
    class CryptHandler
    {

        /**
         * Generates a RSA Key-Pair with the specified length in Bits.
         * 
         * @return A Key-Pair with bits bit length as AssymetricCipherKeyPair object.
         */ 
        public AsymmetricCipherKeyPair generateKey(int bits) {
            RsaKeyPairGenerator r=new RsaKeyPairGenerator();
            r.Init(new KeyGenerationParameters(new SecureRandom (),bits));
            return r.GenerateKeyPair();
        }

        /**
         * Encrypts the given message and returns the ciphertext.
         * 
         * @param message the message which shall be encrypted
         * @param key A string containing the key.
         * @return Returns the encrypted message as string.
         */
        public string encrypt(string message, AsymmetricKeyParameter key)
        {
            SHA256Managed hash = new SHA256Managed();
            SecureRandom randomNumber = new SecureRandom();
            byte[] encodingParam = hash.ComputeHash(Encoding.UTF8.GetBytes(randomNumber.ToString()));
            IAsymmetricBlockCipher e = new OaepEncoding(new RsaEngine(), new Sha256Digest(), encodingParam);


            e.Init(true, key);
            int blockSize = e.GetInputBlockSize();
            List<byte> output = new List<byte>();
            byte[] data = stringToByteArray(message);

            for (int pointerPos = 0; pointerPos < data.Length; pointerPos+=blockSize)
            {
                int chunkSize = Math.Min(blockSize, data.Length - (pointerPos * blockSize));
                output.AddRange(e.ProcessBlock(data, pointerPos, chunkSize));
            }
            return byteArrayToString(output.ToArray());
        }

        /**
         * Converts a String to a byte array.
         * 
         */
        public static byte[] stringToByteArray(string s)
        {
            char[] dataChar = s.ToCharArray();

            byte[] data = new byte[dataChar.Length];

            for (int i=0;i<s.Length;++i) {
                char c = dataChar[i];
                byte b = (byte)c;
                data[i] = b;
            }

            return data;

        }

        /**
         * Converts a String to a byte array.
         * 
         */
        public static string byteArrayToString(byte[] b)
        {
            char[] dataChar = new char[b.Length];

            
            for (int i = 0; i < b.Length; ++i)
            {
                byte by = b[i];
                char c = (char)by;
                dataChar[i] = c;
            }

            return new String(dataChar);

        }

        /**
       * Decrypts the given cipher and returns the ciphertext.
       * 
       * @param cipher the cipher which is encrypted
       * @param key A string containing the key.
       * @return Returns the decrypted message as string.
       */
        public string decrypt(string cipher, AsymmetricKeyParameter key)
        {
            SHA256Managed hash = new SHA256Managed();
            SecureRandom randomNumber = new SecureRandom();
            byte[] encodingParam = hash.ComputeHash(Encoding.UTF8.GetBytes(randomNumber.ToString()));
            IAsymmetricBlockCipher e = new OaepEncoding(new RsaEngine(), new Sha256Digest(), encodingParam);


            e.Init(false, key);
            int blockSize = e.GetInputBlockSize();
            List<byte> output = new List<byte>();
            byte[] data = stringToByteArray(cipher);

            for (int pointerPos = 0; pointerPos < data.Length; pointerPos+=blockSize)
            {
                int chunkSize = Math.Min(blockSize, data.Length - (pointerPos * blockSize));
                output.AddRange(e.ProcessBlock(data, pointerPos, chunkSize));
            }
            return byteArrayToString(output.ToArray());
   
        }

        public static string privkeyToString(AsymmetricKeyParameter key) 
        {
            string keyString = "";

            PrivateKeyInfo pkInfo = PrivateKeyInfoFactory.CreatePrivateKeyInfo(key);
            byte [] serializedBytes=pkInfo.ToAsn1Object().GetDerEncoded();
            keyString = Convert.ToBase64String(serializedBytes);

            return keyString;
        }

        public static string pubkeyToString(AsymmetricKeyParameter key)
        {
            string keyString = "";

            SubjectPublicKeyInfo pkInfo = SubjectPublicKeyInfoFactory.CreateSubjectPublicKeyInfo(key);
            byte[] serializedBytes = pkInfo.ToAsn1Object().GetDerEncoded();
            keyString = Convert.ToBase64String(serializedBytes);

            return keyString;
        }


        public static RsaKeyParameters stringToPubKey(string keyString)
        {
            RsaKeyParameters key = (RsaKeyParameters)PublicKeyFactory.CreateKey(Convert.FromBase64String(keyString));
            return key;
        }

        public static RsaPrivateCrtKeyParameters stringToPrivKey(string keyString)
        {
            RsaPrivateCrtKeyParameters key = (RsaPrivateCrtKeyParameters)PrivateKeyFactory.CreateKey(Convert.FromBase64String(keyString));
            return key;
        }




    }
}
