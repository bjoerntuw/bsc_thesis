﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using Tacet.Handlers;

namespace Tacet
{


    class CorrelationHandler
    {
        internal Tacet.Handlers.OLSResult OLSResult
        {
            get
            {
                throw new System.NotImplementedException();
            }
            set
            {
            }
        }

        internal Tacet.Handlers.StatisticsHelper StatisticsHelper
        {
            get
            {
                throw new System.NotImplementedException();
            }
            set
            {
            }
        }


        public OLSResult leastSquaresFitLines (List<Point> points) {
            OLSResult result = null;
            Point[] pointsFast = points.ToArray();
            double x1, y1, xy, x2, J, k, d;
            int i;

            x1 = 0;
            y1 = 0;
            xy = 0;
            x2 = 0;


            for (i = 0; i < points.Count; ++i)
            {
                x1 = x1 + pointsFast[i].X;
                y1 = y1 + pointsFast[i].Y;
                xy = xy + pointsFast[i].X * pointsFast[i].Y;
                x2 = x2 + pointsFast[i].X * pointsFast[i].X;
            }

            J = ((double)pointsFast.Length * x2) - (x1 * x1);
            if (J != 0)
            {
                k = (((double)pointsFast.Length * xy) - (x1 * y1)) / J;
                k = Math.Floor(1.0E3 * k + 0.5)/1.0E3;
                d = ((y1 * x2) - (x1 * xy)) / J;
                d = Math.Floor(1.0E3 * d + 0.5) / 1.0E3;
            }
            else
            {
                k = 0;
                d = 0;
            }

            result = new OLSResult(new lineParameters(k, d),0);

            return result;
        }

        /**
         * This method performs linear (OLS) regression with 2 correlated variables.
         * 
         * 
         * 
         * 
         * */
        public OLSResult regressionOLS(List<Point> measurePoints)
        {
          

            StatisticsHelper statHelper = new StatisticsHelper(measurePoints);


            double correlation = statHelper.correlationXY();
            double k = statHelper.covXY()/statHelper.varX();
            double d = statHelper.meanY() - k * statHelper.meanX();
            /*
            Debug.WriteLine("berechnungen hier");
            Debug.WriteLine(statHelper.meanX());
            Debug.WriteLine(statHelper.meanY());
            Debug.WriteLine(statHelper.covXY());
            Debug.WriteLine(statHelper.correlationXY());
            Debug.WriteLine(statHelper.stdDevX());
            Debug.WriteLine(statHelper.stdDevY());
                      
            Debug.WriteLine("Regression Equation: "+"y="+k+"x"+"+"+d);
            */
            OLSResult result = new OLSResult(new lineParameters(k, d), correlation);
            return result;
        }

        private void fehlerMeldung(string text)
        {
            System.Windows.MessageBox.Show(text);
        }
    }





}
