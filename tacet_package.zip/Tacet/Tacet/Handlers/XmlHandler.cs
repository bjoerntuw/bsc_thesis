﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Xml;
using System.Xml.Schema;
using Tacet.Handlers;
using Tacet.DAO;


namespace Tacet
{

    /**

	Tacet - A smart symptoms diary for people suffering from Tinnitus.
    Copyright (C) 2014,  Bernhard Brenner <bernhard.brenner@student.tuwien.ac.at>

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.

*/


    class XmlHandler
    {

        private string XMLTEMPLATEPATH;
        private XmlDocument doc = null;
        private LoggingHandler logger = LoggingHandler.getLoggingHandler();

        public XmlHandler(string path, string XmlTemplatePath)
        {
            XMLTEMPLATEPATH=XmlTemplatePath;
            doc = new XmlDocument();
            try
            {
                doc.Load(path);
            }
            catch (Exception ex)
            {
                //sorry, but there is no other way to do this, since its difficult to know which exception types I should beware of!
                logger.FATAL("Fehler beim Einlesen des XML-Dokuments aus Pfad:" + path + " :" + ex.Message);
                throw new XMLHandlerException("Fehler beim Einlesen des XML-Dokuments aus Pfad:" + path + " :" + ex.Message);
            }
        }

        internal Tacet.Handlers.XMLHandlerException XMLHandlerException
        {
            get
            {
                throw new System.NotImplementedException();
            }
            set
            {
            }
        }

        internal Tacet.Helpers.DatagramProcessor DatagramProcessor
        {
            get
            {
                throw new System.NotImplementedException();
            }
            set
            {
            }
        }

        /**
         *  Macht aus dem bereits eingelesenen und geparstem XMl Dokument eine Liste von Datagrammen. 
         * @return Gibt eine Liste mit allen im XML Dokument enthaltenen Datagrammen zurück
         * @throws Wirft eine XMLHandlerException, wenn das document null ist.
         * 
          */
        public List<Datagram> getDatagrams()
        {
            List<Datagram> result = new List<Datagram>();

            if (doc == null)
            {
                throw new XMLHandlerException("Document nicht initialisiert");
                //logger.log("Document nicht initialisiert");
            }


            XmlNodeList l = doc.GetElementsByTagName("Datagram");
            foreach (XmlNode n in l)
            {
                int dID = Convert.ToInt32(n.Attributes["id"].Value);
                DateTime dDate = Convert.ToDateTime(n.Attributes["timestamp"].Value);
                double symptomValue=Convert.ToDouble(n.Attributes["symptomValue"].Value);
                XmlNodeList factorNodes = n.ChildNodes;

                List<Factor> factors = new List<Factor>();

                foreach (XmlNode o in factorNodes)
                {

                    int fid = 0;
                    try
                    {
                        fid = Convert.ToInt32(o.Attributes["fid"].Value);
                    }
                    catch (InvalidCastException e)
                    {
                        throw new XMLHandlerException("Problem with importing XML Data! " + e.Message);
                    }

                    double fValue = Convert.ToDouble(o.Attributes["value"].Value);
                    Factor f = new Factor(fid, fValue);
                    factors.Add(f);
                }

                Datagram d = new Datagram(dID, dDate,symptomValue, factors);
                result.Add(d);
            }

            return result;

        }


        /**
         * Fügt ein neues Datagramm zu dem XML Dokument hinzu.
         * 
         * 
         * @param d  Das Datagramm, bereits mit Daten befüllt.
         * 
         */
        public void addDatagram(Datagram d)
        {
            if (d == null)
            {
                throw new XMLHandlerException("XML-Document nicht initialisiert");
                //logger.log("Document nicht initialisiert");
            }

            XmlElement datagramElement = doc.CreateElement("Datagram");
            datagramElement.SetAttribute("id", "" + d.Id);
            datagramElement.SetAttribute("timestamp", "" + d.Timestamp);
            datagramElement.SetAttribute("symptomValue", "" + d.SymptomValue);


            List<XmlElement> factorElements = new List<XmlElement>();

            foreach (Factor f in d.Factors)
            {
                XmlElement el = doc.CreateElement("factor");
                el.SetAttribute("fid", "" + f.Fid);
                el.SetAttribute("value", "" + f.Value);
                datagramElement.AppendChild(el);
            }


            doc.DocumentElement.AppendChild(datagramElement);

        }

        /**
         * Fügt ein neues Datagramm zu dem übergebenen XML Dokument hinzu.
         * 
         * 
         * @param d  Das Datagramm, bereits mit Daten befüllt.
         * 
         */
        public void addDatagramToDocument(Datagram d, XmlDocument docum)
        {
            if (d == null)
            {
                logger.ERROR("Error adding Datagram to Document: Document not initialised");
                throw new XMLHandlerException("Error adding Datagram to Document: XML-Document not initialised");
                
            }

            XmlElement datagramElement = docum.CreateElement("Datagram");
            datagramElement.SetAttribute("id", "" + d.Id);
            datagramElement.SetAttribute("timestamp", "" + d.Timestamp);
            datagramElement.SetAttribute("symptomValue", "" + d.SymptomValue);

            List<XmlElement> factorElements = new List<XmlElement>();

            foreach (Factor f in d.Factors)
            {
                XmlElement el = docum.CreateElement("factor");
                el.SetAttribute("fid", "" + f.Fid);
                el.SetAttribute("value", "" + f.Value);
                datagramElement.AppendChild(el);
            }


            try
            {
                docum.DocumentElement.AppendChild(datagramElement);
            }
            catch (Exception allgEx)
            {
                logger.FATAL("Error writing Datagram into Document:" + allgEx.Message);
                throw new XMLHandlerException("Error writing Datagram into Document:" + allgEx.Message);
            }

        }

        /**
         * Writes the whole xml-document into an xml-file.
         * 
         * @param path This is the export destination. 
         */

        public void createExportOfThisDocument(string path)
        {
            if (doc == null)
            {
                logger.ERROR("Error with Document-Export:Document not initialised");
                throw new XMLHandlerException("Document not initialised");
              
            }
            doc.Save(path);
        }


        /**Same es createExportOfThisDocument, but takes a list of datagrams instead of 
         * exporting the local stored Document object.
         * 
         * @param dList The Datagram List to be exported. 
         * @param path This is the export destination. 
         */

        public void createExport(List<Datagram> dList, string path)
        {
            XmlDocument exportDoc = new XmlDocument();
            exportDoc.Load(XMLTEMPLATEPATH);

            foreach (Datagram d in dList)
            {
                addDatagramToDocument(d, exportDoc);
            }

            exportDoc.Save(path);
        }

        /**
         * Validates an XML-Document given a specific Scheme.
         * 
         * @return True, if Document is valid false if not.
         */
        public bool validateWithScheme(string schemePath, string documentPath)
        {
            XmlReaderSettings readerSettings = new XmlReaderSettings();
            readerSettings.IgnoreWhitespace = true;
            readerSettings.IgnoreComments = true;
            readerSettings.ValidationType = ValidationType.Schema;
            try
            {
                readerSettings.Schemas.Add(null, schemePath);
            }
            catch (Exception e)
            {
                Console.WriteLine(e.Message);
            }
            readerSettings.ValidationEventHandler += ValidationCallback;
            XmlReader reader = XmlReader.Create(documentPath, readerSettings);
            try
            {
                while (reader.Read())
                {
                    // testing.....
                }
                return true;
            }
            catch (Exception ex)
            {
                logger.ERROR("Failed to Validate the Document. Caught Exception:" + ex.Message);
                return false;
            }
            finally
            {
                reader.Close();
            }
        }
        // Eventhandler
        void ValidationCallback(object sender, ValidationEventArgs e)
        {
            throw e.Exception;
        }

    }
}
