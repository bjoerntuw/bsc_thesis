﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;

namespace Tacet.Handlers
{

    /**

	Tacet - A smart symptoms diary for people suffering from Tinnitus.
    Copyright (C) 2014,  Bernhard Brenner <bernhard.brenner@student.tuwien.ac.at>

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.

*/
    class DirManager
    {
        /**
         * Creates the directory and the files necessary for the storage of the medical data.
         * 
         */
        public static void setUpDataDirectory()
        {
            //create directory
            if (Directory.Exists("data") == false)
            {
                Directory.CreateDirectory("data");
                //throw new Exception(rootPath + "/data");

            }
            

            StreamWriter fileCreator=null;
            //create files and write preset content
            if (File.Exists("data/med_data.xml") == false)
            {
                fileCreator = File.CreateText("data/med_data.xml");
                fileCreator.WriteLine("<Symptomlog>");
                fileCreator.WriteLine("");
                fileCreator.WriteLine("</Symptomlog>");
                fileCreator.Close();
            }
            if (File.Exists("data/template.xml") == false)
            {
                fileCreator = File.CreateText("data/template.xml");
                fileCreator.WriteLine("<Symptomlog>");
                fileCreator.WriteLine("");
                fileCreator.WriteLine("</Symptomlog>");
                fileCreator.Close();
            }
        }

        /**
         * Creates a default configuration file at the specified path.
         *  
         * @return Returns true if the file has been created and false otherwise.
         */
        public static bool createDefaultConfig(string filename)
        {
            
            string content="<?xml version=\"1.0\" encoding=\"utf-8\"?>\n<configuration>\n<appSettings>\n<add key=\"xmlpath\" value=\"./data/med_data.xml\" />\n<add key=\"exportPath\" value=\"./data/med_data.xml\" />\n<add key=\"xmlTemplatePath\" value=\"./data/template.xml\" />\n<add key=\"loggerPath\" value=\"Tacet.log\" />\n<add key=\"firstTime\" value=\"true\" />\n<add key=\"logLevel\" value=\"0\" />\n</appSettings>\n</configuration>";
            if (File.Exists(filename) == false)
            {
                StreamWriter fileCreator = File.CreateText(filename);
                fileCreator.WriteLine(content);
                fileCreator.Close();
                return true;
            }
            return false;

        }
    }
}
