﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Diagnostics;
using Tacet.Handlers;

namespace Tacet
{

    /**

	Tacet - A smart symptoms diary for people suffering from Tinnitus.
    Copyright (C) 2014,  Bernhard Brenner <bernhard.brenner@student.tuwien.ac.at>

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.

*/

    class LoggingHandler
    {

        private static LoggingHandler handler = null;
        public static string path;
        public int level = 2;
        /**
         * This class does all Logging related works.
         * It's implemented as a Singleton (you can only make one instance of it).
         * 
         * There are 5 differen verbosiy Modes:
         * 
         * 1 - DEBUG - System is logging everything (eg "i is 5")
         * 2 - INFO - Information like "Now reading a File."
         * 3 - ERROR - Things that went wrong, but system can go on working. 
         * 4 - FATAL ONLY - Things that went wrong and prohibit further working of the system.
         * 5 - LOGGING OFF - System logs nothing
         * 
         */

        /**
         * Constructor
         * 
         * Initialises the Logger with relevant settings for System.Diagnostics.Trace!
         */
        private LoggingHandler(string logFilePath)
        {
            Trace.Listeners.Add(new TextWriterTraceListener(logFilePath));
            Trace.AutoFlush = true;
        }

        internal Tacet.Handlers.LoggingHandlerException LoggingHandlerException
        {
            get
            {
                throw new System.NotImplementedException();
            }
            set
            {
            }
        }

        public static LoggingHandler getLoggingHandler(string p)
        {
            path = p;
            if (handler == null)
            {
                handler = new LoggingHandler(path);
            }
            return handler;
        }

        public static LoggingHandler getLoggingHandler()
        {
            if (handler == null)
            {
                throw new LoggingHandlerException("You must set the path before you can use the Logger!");
            }
            return handler;
        }

        /**
         * This Method generates the Meta Information for the logs.
         * Example: "Mon, 6.7.2013 10:30 AM - Error:"
         * 
         */
        private string generateMetas(string type)
        {
            return DateTime.Now + " " + type + ": ";
        }

        public void DEBUG(string message)
        {
            if (level <= 1)
                Trace.WriteLine(generateMetas("DEBUG") + message);
        }

        public void INFO(string message)
        {
            if (level <= 2)
                Trace.WriteLine(generateMetas("INFO") + message);
        }

        public void ERROR(string message)
        {
            if (level <= 3)
                Trace.WriteLine(generateMetas("ERROR") + message);
        }

        public void FATAL(string message)
        {
            if (level <= 4)
                Trace.WriteLine(generateMetas("FATAL") + message);
        }



    }
}
