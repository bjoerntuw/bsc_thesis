﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Tacet.Handlers
{


    /**

   Tacet - A smart symptoms diary for people suffering from Tinnitus.
   Copyright (C) 2014,  Bernhard Brenner <bernhard.brenner@student.tuwien.ac.at>

   This program is free software: you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation, either version 3 of the License, or
   (at your option) any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with this program.  If not, see <http://www.gnu.org/licenses/>.
      
      
      
    Original Author of this Class: Yossi Rozenberg, Israel, Nov 2013. 
    licensed under  "The Code Project Open License (CPOL)".
    Downloaded from:http://www.codeproject.com/KB/cs/csstatistics.aspx and modified on March, 13, 2014 
    by Bernhard Brenner <bernhard.brenner@student.tuwien.ac.at>


*/

    /**
     * This class implements basic statistical functions.
     * 
     * 
     * 
     * 
     */


    class Statistics
    {
        public Statistics()
        {

        }


        public double mean(double[] list)
        {
            try
            {
                double sum = 0;
                for (int i = 0; i <= list.Length - 1; i++)
                    sum += list[i];
                return sum / list.Length;
            }
            catch (DivideByZeroException)
            {
                return double.NaN;
            }

        }

        public double var(double[] list)
        {
            try
            {
                double sum = 0;
                double meanDiff=0;
                double squaredMeanDiff=0;
                double meanValue=mean(list);
                double n = list.Length;
                for (int i = 0; i < list.Length; ++i)
                {
                    meanDiff=Math.Abs(list[i]-meanValue);
                    squaredMeanDiff=Math.Pow(meanDiff,2.0);
                    sum += squaredMeanDiff;
                }
                return sum / n;
            }
            catch (DivideByZeroException)
            {
                return double.NaN;
            }
        }

        public double stdDev(double[] list)
        {
            return Math.Sqrt(var(list));
        }

        public double cov(double [] list1, double [] list2)
        {
            try
            {
                if (list1.Length != list2.Length) 
                    return double.NaN;
                int len = list1.Length;
                double sum_mul = 0;
                for (int i = 0; i <= len - 1; i++)
                    sum_mul += (list1[i] * list2[i]);
                return (sum_mul - len * mean(list1) * mean(list2)) / len;
            }
            catch (DivideByZeroException)
            {
                return double.NaN;
            }
        }
    }
}
