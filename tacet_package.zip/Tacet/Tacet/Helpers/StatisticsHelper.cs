﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Tacet.Handlers
{
    using System;

     /**

	Tacet - A smart symptoms diary for people suffering from Tinnitus.
    Copyright (C) 2014,  Bernhard Brenner <bernhard.brenner@student.tuwien.ac.at>

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
      
      
      
      


*/

    /**
     * This class implements functions for statistical calculations implemented on Point-Lists.
     *  
     */

         class StatisticsHelper
        {

            private List<Point> measurePointsList=null;
    
            private double [] xList=null;
            private double [] yList=null;

            private Statistics stat = null;

            public StatisticsHelper(List<Point> measurePointsList)
            {
                this.measurePointsList=measurePointsList;
                stat = new Statistics();
                extractXArray();
                extractYArray();
            }

            internal Statistics Statistics
            {
                get
                {
                    throw new System.NotImplementedException();
                }
                set
                {
                }
            }


            public void update(List<Point> measurePointsList)
            {
                this.measurePointsList=measurePointsList;
                extractXArray();
                extractYArray();
            }

            
            private void extractXArray () {
                xList=new double [measurePointsList.Count];
                for(int i=0;i<measurePointsList.Count();++i) {
                    xList[i]=measurePointsList.ElementAt(i).X;
                }

            }

            private void extractYArray() {
                yList=new double [measurePointsList.Count];
                for(int i=0;i<measurePointsList.Count();++i) {
                    yList[i]=measurePointsList.ElementAt(i).Y;
                }
            }

           public double meanX()
           {
             return stat.mean(xList);
           }

           public double meanY()
           {
             return stat.mean(yList);
           }

           public double stdDevX()
           {
               return stat.stdDev(xList);
           }

           public double stdDevY()
           {
               return stat.stdDev(yList);
           }

           public double covXY() {
               return stat.cov(xList, yList);
           }

           public double correlationXY()
           {
               return (covXY() / (stdDevX() * stdDevY()));
           }

           public double varX()
           {
               return stat.var(xList);
           }

           public double varY()
           {
               return stat.var(yList);
           }
        }
}
