﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Security.Cryptography;
using Org.BouncyCastle.Security;
using Tacet.Handlers;

namespace Tacet
{

    /**

	Tacet - A smart symptoms diary for people suffering from Tinnitus.
    Copyright (C) 2014,  Bernhard Brenner <bernhard.brenner@student.tuwien.ac.at>

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.

*/


    class IDGenerator
    { 
        /**
         * This class uses SecureRandom class from bouncycastle cryptolibrary to generate a
         * unique Hash with which a user can be identified.
         *  
         */
        public static string generateUniqueID()
        {
            SecureRandom sr = new SecureRandom();
            string s = "";
            byte [] buffer=new byte[512];
            sr.NextBytes(buffer);
            s = Convert.ToBase64String(buffer);
            return generateMD5Hash(s);
        }

        /*
         * This method is copied from :https://blogs.msdn.com/b/csharpfaq/archive/2006/10/09/how-do-i-calculate-a-md5-hash-from-a-string_3f00_.aspx?Redirected=true
         * on 18.10.2013 14:47 by Bernhard Brenner
         * 
         * It generates a MD5 Hash from a given String data.
         */
        private static string generateMD5Hash(string input)
        {
            // step 1, calculate MD5 hash from input
            MD5 md5 = System.Security.Cryptography.MD5.Create();
            byte[] inputBytes = System.Text.Encoding.ASCII.GetBytes(input);
            byte[] hash = md5.ComputeHash(inputBytes);

            // step 2, convert byte array to hex string
            StringBuilder sb = new StringBuilder();
            for (int i = 0; i < hash.Length; i++)
            {
                sb.Append(hash[i].ToString("X2"));
            }
            return sb.ToString();
        }

    }
}
