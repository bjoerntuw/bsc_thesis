﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Text;
using Tacet.DAO;

namespace Tacet.Helpers
{
    class DatagramProcessor
    {
        internal Tacet.DAO.Datagram Datagram
        {
            get
            {
                throw new System.NotImplementedException();
            }
            set
            {
            }
        }


   /**
   * Returns a well-readable representation of this Datagram.
   * Ready for placing it into a ListBox for example.
   * 
   */
        public static string datagramtoString(int factorCount, Datagram d)
        {
            string finished = "";

            finished += "|" + fillItemStrings("" + d.Id, 4);
            finished += "|" + fillItemStrings(d.Timestamp.ToString().Replace(" ", "  |  "), 28);
            finished += "|" + fillItemStrings("" + d.SymptomValue, 9);
            finished += "|" + fillItemStrings("" + d.Factors.ElementAt(0).Value, 9);
            if (factorCount >= 2)
                finished += "|" + fillItemStrings("" + d.Factors.ElementAt(1).Value, 9);
            if (factorCount == 3)
                finished += "|" + fillItemStrings("" + d.Factors.ElementAt(2).Value, 9) + "|";

            return finished;
        }


        /*4,21,19,10,13,13,13*/
        private static string fillItemStrings(string data, int desiredLength)
        {

            int side = (desiredLength - data.Length) / 2;

            if (side < 0)
                return data;

            string erg = "";
            if ((side * 2) < (desiredLength - data.Length))
                erg += " ";

            for (int i = 0; i < side; ++i)
            {
                erg += " ";
            }
            erg += data;

            for (int i = 0; i < side; ++i)
            {
                erg += " ";
            }
            return erg;

        }



        /**
   * Converts the Listbox-type- Datagram into a DAO Object Datagram .
   * 
   */
        public static Datagram stringToDatagram(string line)
        {
            Datagram d = null;
            char[] sep = { '|', '|', '|', '|', '|', '|', '|', '|' };
            string[] alleS = line.Split(sep);
            double[] alleD = new double[7];
            int i = 0;
            foreach (String s in alleS)
            {
                string t = s.Trim();
                alleS[i] = t;
                i++;
            }

            //id
            alleD[0] = Convert.ToDouble(alleS[1]);
            //symptom
            alleD[1] = Convert.ToDouble(alleS[4]);
            //f1
            alleD[2] = Convert.ToDouble(alleS[5]);
            //f2
            if (alleS.Length >= 7)
                alleD[3] = Convert.ToDouble(alleS[6]);
            //f3
            if (alleS.Length >= 8)
                alleD[4] = Convert.ToDouble(alleS[7]);



            string dateS = alleS[2] + " " + alleS[3];
            DateTime timestamp = Convert.ToDateTime(dateS);
            List<Factor> fList = new List<Factor>();
            fList.Add(new Factor(1, alleD[2]));
            fList.Add(new Factor(2, alleD[3]));
            fList.Add(new Factor(3, alleD[4]));


            d = new Datagram((int)alleD[0], timestamp, alleD[1], fList);
            return d;
        }

    }
}
