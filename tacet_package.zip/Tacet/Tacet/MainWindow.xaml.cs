﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using System.Configuration;
using System.Xaml;
using Tacet.Handlers;
using System.IO;
using System.Reflection;

namespace Tacet
{


    /**

	Tacet - A smart symptoms diary for people suffering from Tinnitus.
    Copyright (C) 2014,  Bernhard Brenner <bernhard.brenner@student.tuwien.ac.at>

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.

*/


    /// <summary>
    /// Interaktionslogik für Main.xaml
    /// </summary>
    public partial class Main : Window
    {
        private const string PROGRAMVERSION = "Tacet 1.3 Alpha";
        private const string LICENSE = "Tacet - A smart symptoms diary for people suffering from Tinnitus. \nCopyright (C) 2014,  Bernhard Brenner <bernhard.brenner@student.tuwien.ac.at> \nVersion: " + PROGRAMVERSION + "\n\nThis program is free software: you can redistribute it and/or modify it under the terms of the GNU General Public License as published by the Free Software Foundation, either version 3 of the License, or (at your option) any later version. This program is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General Public License for more details. You should have received a copy of the GNU General Public License along with this program.  If not, see <http://www.gnu.org/licenses/>.";

        private LoggingHandler logger = null;
        private ConfigurationHandler config=null;

        int factorCount = 0;

       
        //The following variables will be read by configuration file reader.
       private string loggerPath = "";
       private string xmlpath = "";
       private string xmlTemplatePath = "";
       private bool firstTime = true;
       private string exportPath = "";
       private string dailyLogTime = "";
       private string factorOneName = "";
       private string factorTwoName = "";
       private string factorThreeName = "";
       private string clientId = "";
       private string logLevel = "1";
       private string logLater = "";

        //public RSA-4096-key for encryption of the patient's data. 
       private string key = "MIICIjANBgkqhkiG9w0BAQEFAAOCAg8AMIICCgKCAgEAzrp2+FZlLTEGX5uGRLWob9mtocb3wKqX6raLn5iSeNEb5926efdXK+E8bgipHbcepXCcd1u0ACbOc46oQtuHhpgKLtKuLRTc+Bg8gEeDvZvghgC1hCMh6Rt/tt8pIjtWc6QcnsfaA4bKLrN0qdjkDj1pqwgFrNXuXDPQLMQucc7Z2pc5k3QWD/Ak2iHi7FeYrqz+Nk7EPM/sCCgAYi/5y+QcyoSG9SFFv8/Dd0RLFQEgr0EahHqW5rtHZLF9ayfA/jdTerziHc3V3Ti7dIFyXoz7a6C9Yvz5trP2QdRqfaOko9TdR7fi/unzuvZIP2ANSC84rcGZNv1iErjH7MhXORnj1IcS4FxpuwF7uoxwLMJPQAvdT10S2IIWECt3ICfa4mGmoIsWB6CTIHHWpsnevQ8u5ywf62MWJzSyDDMiz9KcM/Jq6T+dXR2Vqgika6weR8eKaAmuWVEWPd5+ILV0UkreFjEnNLAjez/XAQrwp3OvJV5XzVrW2Mck2J7knLXQH5+/rO91NqZK1LTSVjGLkg2bxdbIdjOOeVO5a7sSygxvK6t9pAZ5qIBwHIfwl2WmAf8faz971X7EF27yiqzsb3p/RIGag1c22A3NkPzWTrPKHIS+hs20D7yD4eXKwZPndy9viwZDu5fBJmffYBnFb2h1jvVdFzGx9AH/vg/163UCAwEAAQ==";
      

       public Main()
       {
           //Here is the DEBUG-Zone



           //End of the DEBUG-Zone
           try
           {
               //if there is no configuration file at all, we have to create a preset configuration file so the program can start properly
               //The DirManager only creates a config file, if there does not already exist one.
               DirManager.setUpDataDirectory();
               DirManager.createDefaultConfig("Tacet.config");
               
               //Initialize Configuration File Reader
               config = new ConfigurationHandler("Tacet.config");
               if (config == null)
               {
                   fehlerMeldungNL("Konfigurationsdatei fehlt!");
                   this.Close();
               }

         
               
               //Reading Configuration
               try
               {
                   firstTime = (config.getConfigString("firstTime").Equals("true"));
                   if (firstTime == false)
                   {
                       dailyLogTime = config.getConfigString("dailyLogTime");
                       factorOneName = config.getConfigString("factorOneName");
                       factorCount = 1;
                       clientId = config.getConfigString("clientId");
                   }

                   xmlpath = config.getConfigString("xmlpath");
                   exportPath = config.getConfigString("exportPath");
                   xmlTemplatePath = config.getConfigString("xmlTemplatePath");
                   loggerPath = config.getConfigString("loggerPath");

                   
                   
               }
               catch (Exception e)
               {
                  logLater+="Fehler beim Einlesen der Konfígurationsdatei:"+e.Message+";";
               }

           }
           catch (Exception ex)
           {
               fehlerMeldungNL("Fehler: " + ex.Message);
           }

               try
               {
                   logLevel = config.getConfigString("logLevel");
                   factorTwoName = config.getConfigString("factorTwoName");
                   if (factorTwoName != "")
                       factorCount = 2;
                   factorThreeName = config.getConfigString("factorThreeName");
                   if (factorThreeName != "")
                       factorCount = 3;
               }
               catch (Exception e)
               {
                   //Options that may not be confiured explicitly.
                   logLater+="Gefunden bei Konfiguration: "+e.Message+" - Kann daran liegen, dass weniger als 3 Faktoren benutzt werden.;";
               }

               //Initialize Logger
               logger = LoggingHandler.getLoggingHandler(loggerPath);
               try
               {
                   logger.level = Convert.ToInt32(logLevel);
               }
               catch (Exception)
               {
                   logger.level = 1;
               }

               //Program starts!

               logger.DEBUG("Starting up");
               this.InitializeComponent();


               if (firstTime)
               {
                   logger.INFO("Generating Unique ID");
                   string newID = IDGenerator.generateUniqueID();
                   logger.INFO("Unique ID is " + newID);
                   config.setConfigString("clientId", newID);
                   this.clientId = newID;

                   logger.INFO("Showing First-Time-Window.");
                   FirstTimePopup pop = new FirstTimePopup();
                   pop.Show();
                   pop.Activate();
                   pop.Topmost = true;
                   cbaddFactor.SelectedIndex = 0;
               }
               else
               {
                   //Setting up some GUI Details

                   tbUhrzeitStunden.Text = dailyLogTime.Substring(0,dailyLogTime.IndexOf(":"));
                   tbUhrzeitMinuten.Text = dailyLogTime.Substring(dailyLogTime.IndexOf(":")+1);
                   lbFaktoren.Items.Add(factorOneName);
                   if(factorCount>=2)
                       lbFaktoren.Items.Add(factorTwoName);
                   if(factorCount==3)
                       lbFaktoren.Items.Add(factorThreeName);

                   bMEL.IsEnabled = false;
                   bSpeichern.IsEnabled = false;
                   bHinzufuegen.IsEnabled = false;
                   tbFaktorHinzufuegen.IsEnabled = false;
                   tbUhrzeitStunden.IsEnabled = false;
                   tbUhrzeitMinuten.IsEnabled = false;
                   cbaddFactor.IsEnabled = false;

                   //LogPlot page
                   cFaktor1.Content = shortenString(factorOneName,10);
                   cFaktor2.Content = shortenString(factorTwoName,8);
                   cFaktor3.Content = shortenString(factorThreeName,9);

                   if (factorCount < 3)
                   {
                       cFaktor3.IsEnabled = false;
                       cFaktor3.Content = "Faktor 3";
                       cFaktor3.Visibility = Visibility.Hidden;
                   }

                   if (factorCount < 2)
                   {
                       cFaktor2.IsEnabled = false;
                       cFaktor2.Content = "Faktor 2";
                       cFaktor2.Visibility = Visibility.Hidden;
                   }

                   
                   
                   
                   dropRight.Items.Add("Tinnitus-Lautstärke (dB)");

                   dropLeft.Items.Add(factorOneName);
                   dropRight.Items.Add(factorOneName);

                   if (factorCount >= 2)
                   {
                       dropLeft.Items.Add(factorTwoName);
                       dropRight.Items.Add(factorTwoName);
                   }

                   if (factorCount == 3)
                   {
                       dropLeft.Items.Add(factorThreeName);
                       dropRight.Items.Add(factorThreeName);
                   }

                       
                   //Importing the Data and Plotting the Graphs
                   datenImportieren();
                   plotGraphAfterStart();


                   ///setting the icon
                   Uri iconUri = new Uri("tacet_icon.ico", UriKind.RelativeOrAbsolute);
                   this.Icon = BitmapFrame.Create(iconUri);


                   logger.ERROR(logLater);

               }

          
           
           
          }

       public AddItem AddItem
       {
           get
           {
               throw new System.NotImplementedException();
           }
           set
           {
           }
       }

       public FirstTimePopup FirstTimePopup
       {
           get
           {
               throw new System.NotImplementedException();
           }
           set
           {
           }
       }

       public ChangeItem ChangeItem
       {
           get
           {
               throw new System.NotImplementedException();
           }
           set
           {
           }
       }

       public Disclaimer Disclaimer
       {
           get
           {
               throw new System.NotImplementedException();
           }
           set
           {
           }
       }

       internal Tacet.Handlers.DirManager DirManager
       {
           get
           {
               throw new System.NotImplementedException();
           }
           set
           {
           }
       }

       internal IDGenerator IDGenerator
       {
           get
           {
               throw new System.NotImplementedException();
           }
           set
           {
           }
       }

       internal Tacet.Handlers.CryptHandler CryptHandler
       {
           get
           {
               throw new System.NotImplementedException();
           }
           set
           {
           }
       }

       internal XmlHandler XmlHandler
       {
           get
           {
               throw new System.NotImplementedException();
           }
           set
           {
           }
       }

       internal ConfigurationHandler ConfigurationHandler
       {
           get
           {
               throw new System.NotImplementedException();
           }
           set
           {
           }
       }

       internal Tacet.Handlers.MailHandler MailHandler
       {
           get
           {
               throw new System.NotImplementedException();
           }
           set
           {
           }
       }

       internal LoggingHandler LoggingHandler
       {
           get
           {
               throw new System.NotImplementedException();
           }
           set
           {
           }
       }

       CorrelationHandler CorrelationHandler
       {
           get
           {
               throw new System.NotImplementedException();
           }
           set
           {
           }
       }

       internal Point Point
       {
           get
           {
               throw new System.NotImplementedException();
           }
           set
           {
           }
       }

        /*
         * reduces the length of a string to the length given length maxLen.
         * 
         */
       private string shortenString(string s, int maxLen)
       {
           if (s.Length > maxLen)
           {
               s = s.Substring(0, maxLen);
           }
           return s;
       }

       

        /* */
        /**
         * NL means "NON LOGGING"
         */
       private void fehlerMeldungNL(string text)
       {
           System.Windows.MessageBox.Show(this, text);
       }
        
        private void fehlerMeldung(string text)
        {
            logger.ERROR("Error:" + text);
            System.Windows.MessageBox.Show(this, text);
        }

        private void infoMeldung(string text)
        {
            logger.INFO(text);
            System.Windows.MessageBox.Show(this, text);
        }

        private bool schonVorhanden(string text)
        {
            for (int i = 0; i < lbFaktoren.Items.Count; ++i)
            {
                if (lbFaktoren.Items.GetItemAt(i).ToString().Equals(text))
                {
                    logger.DEBUG("is already added to Factors:" + text);
                    return true;
                }

            }
            return false;

        }

        private void addFactor()
        {
            if (cbaddFactor.SelectedItem==null)
                return;

            if (cbaddFactor.SelectedItem.ToString().Equals("Einheit wählen"))
            {
                infoMeldung("Sie müssen erst eine Einheit wählen!");
                return;
            }
            if (tbFaktorHinzufuegen.Text.Equals("Einflussfaktor eingeben") || tbFaktorHinzufuegen.Text.Equals(""))
                return;

            string eingabeFaktor = tbFaktorHinzufuegen.Text + " (" + convertUnitsToKuerzel(cbaddFactor.SelectedItem.ToString()) + ")";

            if (schonVorhanden(eingabeFaktor))
                return;
            if (lbFaktoren.Items.Count == 3)
            {
                fehlerMeldung("Es dürfen nur maximal 3 Einflussfaktoren gewählt werden");
                return;
            }
            
            lbFaktoren.Items.Add(eingabeFaktor);
            tbFaktorHinzufuegen.Text = "";
            logger.DEBUG("Added Factor:" + eingabeFaktor);
        }
        private void bHinzufuegen_Click(object sender, RoutedEventArgs e)
        {
            addFactor();
        }

        private void bMEL_Click(object sender, RoutedEventArgs e)
        {
            if (lbFaktoren.SelectedItem != null)
            {
                logger.DEBUG("Removing Factor:" + lbFaktoren.SelectedItem.ToString());
                lbFaktoren.Items.Remove(lbFaktoren.SelectedItem);
            }
        }

        private void tbUhrzeitStunden_GotFocus(object sender, RoutedEventArgs e)
        {
            if (tbUhrzeitStunden.Text.Equals("HH"))
            {
                tbUhrzeitStunden.Text = "";
            }
        }

        private void tbUhrzeitMinuten_GotFocus(object sender, RoutedEventArgs e)
        {
            if (tbUhrzeitMinuten.Text.Equals("MM"))
            {
                tbUhrzeitMinuten.Text = "";
            }
        }

        private void tbUhrzeitStunden_LostFocus(object sender, RoutedEventArgs e)
        {
            if (tbUhrzeitStunden.Text.Equals(""))
            {
                tbUhrzeitStunden.Text = "HH";
            }
        }

        private void tbUhrzeitMinuten_LostFocus(object sender, RoutedEventArgs e)
        {
            if (tbUhrzeitMinuten.Text.Equals(""))
            {
                tbUhrzeitMinuten.Text = "MM";
            }
        }
   
        private void mBeenden_Click(object sender, RoutedEventArgs e)
        {
            logger.INFO("Program ends");
            this.Close();
        }

        private void mHandBuch_Click(object sender, RoutedEventArgs e)
        {
            fehlerMeldung("Not implemented yet!");
        }

        private void mUeber_Click(object sender, RoutedEventArgs e)
        {
            infoMeldung(LICENSE);
        }

        private void bSpeichern_Click(object sender, RoutedEventArgs e)
        {
            if (saveConfiguration())
            {
                infoMeldung("Konfiguration speichern Erfolgreich!");
                System.Windows.Forms.Application.Restart();
                this.Close();
            }
        }

        private bool saveConfiguration()
        {
            string uhrzeit = tbUhrzeitStunden.Text+":"+tbUhrzeitMinuten.Text;

            try
            {
                Convert.ToInt32(tbUhrzeitStunden.Text);
                Convert.ToInt32(tbUhrzeitMinuten.Text);
            }
            catch (FormatException)
            {
                fehlerMeldung("Bitte stellen Sie eine korrekte Uhrzeit ein!");
                return false;
            }

            string factor1Name = "";
            string factor2Name = "";
            string factor3Name = "";
           

            try
            {
               factor1Name = lbFaktoren.Items.GetItemAt(0).ToString();
               factor2Name = lbFaktoren.Items.GetItemAt(1).ToString();
               factor3Name = lbFaktoren.Items.GetItemAt(2).ToString();
            }
            catch (Exception)
            {
                if (lbFaktoren.Items.Count < 1)
                {
                    fehlerMeldung("Mindestens 1 Faktor benötigt!");
                    return false;
                }
            }


            config.setConfigString("dailyLogTime", uhrzeit);
            config.setConfigString("factorOneName", factor1Name);
            config.setConfigString("factorTwoName", factor2Name);
            config.setConfigString("factorThreeName", factor3Name);

            config.setConfigString("firstTime", "false");
            return true;

        }

        private void tbFaktorHinzufuegen_GotFocus(object sender, RoutedEventArgs e)
        {
            if (tbFaktorHinzufuegen.Text.Equals("Einflussfaktor eingeben"))
            {
                tbFaktorHinzufuegen.Text = "";
            }
        }

        private void tbFaktorHinzufuegen_LostFocus(object sender, RoutedEventArgs e)
        {
            if (tbFaktorHinzufuegen.Text.Equals(""))
            {
                tbFaktorHinzufuegen.Text = "Einflussfaktor eingeben";
            }
        }

        private void tbFaktorHinzufuegen_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.Key == Key.Return)
            {
                addFactor();
            }
        }

        private string convertUnitsToKuerzel(string unit)
        {
            string result = unit.Substring(unit.IndexOf("-") + 2);
            return result;
        }
   
   
       


    

  
    }
}