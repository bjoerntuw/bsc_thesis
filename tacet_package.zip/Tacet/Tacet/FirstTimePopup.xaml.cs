﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace Tacet
{


    /**

	Tacet - A smart symptoms diary for people suffering from Tinnitus.
    Copyright (C) 2014,  Bernhard Brenner <bernhard.brenner@student.tuwien.ac.at>

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.

*/


    /// <summary>
    /// Interaktionslogik für FirstTimePopup.xaml
    /// </summary>
    public partial class FirstTimePopup : Window
    {
        public FirstTimePopup()
        {
            this.InitializeComponent();
            // Fügen Sie Code, der bei der Objekterstellung erforderlich ist, unter diesem Punkt ein.
        }

        private void bOK_Click(object sender, RoutedEventArgs e)
        {
            this.Close();
        }
    }
}