﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using Tacet.DAO;
using Tacet.Handlers;
using Tacet.Helpers;

namespace Tacet
{


    /**

	Tacet - A smart symptoms diary for people suffering from Tinnitus.
    Copyright (C) 2014,  Bernhard Brenner <bernhard.brenner@student.tuwien.ac.at>

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.

*/



    public partial class ChangeItem : Window
    {
        private LoggingHandler logger = LoggingHandler.getLoggingHandler();
        private int itsID = 0;
        private DateTime stamp;
        private int insertIndex=0;
        private int factorCount = 0;

        private Main window;

        public int LastID
        {
            get { return itsID; }
            set { itsID = value; }
        }
        public ChangeItem(int ID, DateTime stamp, double sL, double f1, double f2, double f3, int insertIndex, string f1Name, string f2Name, string f3Name, int sel,Main window, int factorCount)
        {
            InitializeComponent();
            this.itsID = ID;
            tSymptom.Text = "" + sL;
            tFactor1.Text = "" + f1;
            tFactor2.Text = "" + f2;
            tFactor3.Text = "" + f3;
            this.stamp = stamp;
            this.insertIndex = insertIndex;
            this.sel = sel;

            lErsterFaktor.Content = f1Name;
            lZweiterFaktor.Content = f2Name;
            lDritterFaktor.Content = f3Name;

            if (lZweiterFaktor.Content.Equals(""))
            {
                tFactor2.IsEnabled = false;
                tFactor3.IsEnabled = false;
              
                tFactor2.Visibility = Visibility.Hidden;
                tFactor3.Visibility = Visibility.Hidden;
                
            }
            if (lDritterFaktor.Content.Equals(""))
            {
                tFactor3.IsEnabled = false;
                tFactor3.Visibility = Visibility.Hidden;
            }

            this.window = window;
            this.factorCount = factorCount;
        }

        private void bSpeichern2_Click(object sender, RoutedEventArgs e)
        {
            List<Factor> fList = new List<Factor>();
            try
            {
                Convert.ToDouble(tSymptom.Text);

                tFactor1.Text = tFactor1.Text.Replace(".", ",");
                tFactor2.Text = tFactor2.Text.Replace(".", ",");
                tFactor3.Text = tFactor3.Text.Replace(".", ",");
                tSymptom.Text = tSymptom.Text.Replace(".", ",");

                fList.Add(new Factor(1, Convert.ToDouble(tFactor1.Text)));
                fList.Add(new Factor(2, Convert.ToDouble(tFactor2.Text)));
                fList.Add(new Factor(3, Convert.ToDouble(tFactor3.Text)));
            }
            catch (FormatException)
            {
                logger.ERROR("Error while adding new Tag:Kein zulässiger Tag eingegeben!");
                fehlerMeldung("Kein zulässiger Tag eingegeben!");
                return;
            }
            Datagram d = new Datagram(itsID, stamp, Convert.ToDouble(tSymptom.Text), fList);

            Main.LiveAnsicht.Items.RemoveAt(this.sel);
            Main.LiveAnsicht.Items.Insert(insertIndex,DatagramProcessor.datagramtoString(factorCount,d));
            Main.LiveAnsicht.SelectedIndex = sel;
            window.datenExportieren();
            this.Close();
        }

        private void fehlerMeldung(string text)
        {
            logger.ERROR("Error:" + text);
            System.Windows.MessageBox.Show(this, text);
        }






        public int sel { get; set; }

        private void bcancelChangeItem_Click(object sender, RoutedEventArgs e)
        {
            this.Close();
        }


    }
}
