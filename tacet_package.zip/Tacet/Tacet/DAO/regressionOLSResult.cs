﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Tacet.Handlers
{
    class OLSResult
    {
        private lineParameters lp;
        private double correlationCoefficient;


        internal lineParameters Lp
        {
            get { return lp; }
            set { lp = value; }
        }


        public double Correlation
        {
            get { return correlationCoefficient; }
            set { correlationCoefficient = value; }
        }

        internal Tacet.lineParameters lineParameters
        {
            get
            {
                throw new System.NotImplementedException();
            }
            set
            {
            }
        }

        public OLSResult(lineParameters lp, double correlation)
        {
            this.lp = lp;
            this.correlationCoefficient = correlation;
        }

        internal lineParameters getLineParameters()
        {
            return this.lp;
        }
    }
}
