﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using Tacet.Handlers;
using Tacet.DAO;
using Microsoft.Research.DynamicDataDisplay;
using Microsoft.Research.DynamicDataDisplay.DataSources;
using Microsoft.Research.DynamicDataDisplay.PointMarkers;
using System.Collections.ObjectModel;
namespace Tacet
{


    /**

	Tacet - A smart symptoms diary for people suffering from Tinnitus.
    Copyright (C) 2014,  Bernhard Brenner <bernhard.brenner@student.tuwien.ac.at>

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.

*/


    /**
     * Here is everything about Processing the collected data - from the ViewModel.
     * 
     * 
     */
    public partial class Main : Window
    {

        private bool calculatesFirstTime = true;

        private EnumerableDataSource<Double> xDataSource;
        private EnumerableDataSource<Double> yDataSource;


        private void graph(List<Double> xList, List<Double> yList, string descr)
        {

            try
            {
                if (xList == null)
                    return;
                logger.DEBUG("Plotting a Regression graph of " + xList.Count + " Datagrams");
                xDataSource = new EnumerableDataSource<Double>(xList);
                xDataSource.SetXMapping(x => x);

                yDataSource = new EnumerableDataSource<Double>(yList);
                yDataSource.SetYMapping(y => y);

                CompositeDataSource compositeDataSource1 = new
                CompositeDataSource(xDataSource, yDataSource);


                regPlotter.AddLineGraph(compositeDataSource1,
                   new Pen(Brushes.Blue, 2),
                   new CirclePointMarker { Size = 3.0, Fill = Brushes.Red },
                   new PenDescription(descr));
            }
            catch (InvalidCastException e)
            {
                fehlerMeldung("Failed to Plot:Got Invalid Cast Exception:" + e.Message);
            }

            regPlotter.Viewport.FitToView();
        }

        private void graphColour(List<Double> xList, List<Double> yList,Pen colour, CirclePointMarker marker, string descr)
        {

            try
            {
                if (xList == null)
                    return;
                logger.DEBUG("Plotting a correlation-result graph of " + xList.Count + " Datagrams");
                xDataSource = new EnumerableDataSource<Double>(xList);
                xDataSource.SetXMapping(x => x);

                yDataSource = new EnumerableDataSource<Double>(yList);
                yDataSource.SetYMapping(y => y);

                CompositeDataSource compositeDataSource1 = new
                CompositeDataSource(xDataSource, yDataSource);


                regPlotter.AddLineGraph(compositeDataSource1,
                   colour,
                   marker,
                   new PenDescription(descr));
            }
            catch (InvalidCastException e)
            {
                fehlerMeldung("Failed to Plot:Got Invalid Cast Exception:" + e.Message);
            }

            regPlotter.Viewport.FitToView();
        }




        private void graphScatter(List<Double> xList, List<Double> yList, string descr)
        {

            try
            {
                if (xList == null)
                    return;
                logger.DEBUG("Plotting a Scatter graph of " + xList.Count + " Datagrams");
                xDataSource = new EnumerableDataSource<Double>(xList);
                xDataSource.SetXMapping(x => x);

                yDataSource = new EnumerableDataSource<Double>(yList);
                yDataSource.SetYMapping(y => y);

                CompositeDataSource compositeDataSource1 = new
                CompositeDataSource(xDataSource, yDataSource);


                regPlotter.AddLineGraph(compositeDataSource1,
                   new Pen(Brushes.Blue, 0),
                   new CirclePointMarker { Size = 3.0, Fill = Brushes.Red },
                   new PenDescription(descr));
            }
            catch (InvalidCastException e)
            {
                fehlerMeldung("Failed to Plot:Got Invalid Cast Exception:" + e.Message);
            }

            regPlotter.Viewport.FitToView();
        }


        /**
         * Extracts numerical data out of a List of Datagrams.
         * 
         * @param what: The column you want
         */
        private List<Double> getPoints(List<Datagram> data, int what)
        {
            List<Double> resList = new List<Double>();

            if (what == 0)
            {
                foreach (Datagram d in data)
                {
                    resList.Add(d.SymptomValue);
                }
            }

            else
            {
                foreach (Datagram d in data)
                {
                    resList.Add(d.Factors.ElementAt(what-1).Value);
                }
            }
            return resList;
        }


        private void bAuswerten_Click(object sender, RoutedEventArgs e)
        {
            resetCalcGraph();
          if (dropLeft.SelectedItem == null || dropRight.SelectedItem == null)
            {
                return;
            }
            if (dropLeft.SelectedItem.Equals(dropRight.SelectedItem))
            {
                fehlerMeldung("Es kann kein Faktor mit sich selbst ausgewertet werden!");
                return;
            }

            if (datenAnsichtEmpty())
            {
                fehlerMeldung("Noch keine Daten vorhanden!");
                return;
            }
            if (this.calculatesFirstTime == true)
            {
                Disclaimer dis = new Disclaimer();
                dis.Show();
                dis.Activate();
                dis.Topmost = true;
                this.calculatesFirstTime = false;
            }
            List<Double> xPoints = new List<Double>();
            List<Double> yPoints = new List<Double>();

            int whatX=dropLeft.SelectedIndex+1;
            int whatY = dropRight.SelectedIndex;

            xPoints = getPoints(dataList,whatX);
            yPoints = getPoints(dataList, whatY);

            graphScatter(xPoints, yPoints,""+dropLeft.SelectedItem.ToString()+" - "+dropRight.SelectedItem.ToString());

            List<Point> pl = new List<Point>();

            for (int i = 0; i < xPoints.Count; ++i)
            {
                Point p = new Point(xPoints.ElementAt(i), yPoints.ElementAt(i));
                pl.Add(p);
            }
            double max = xPoints.Max();
            OLSResult res = new CorrelationHandler().regressionOLS(pl);


            plotCertainLine(res.getLineParameters(), max, max/100, "Lineare Regression\nKorrelation: "+Math.Round(res.Correlation,3),new Pen(Brushes.Blue,1));

            regBeschriftungX.Content = dropLeft.SelectedItem.ToString();
            regBeschriftungY.Content = dropRight.SelectedItem.ToString();
        }

        private void resetCalcGraph()
        {
            clearRegressionLines();

            regBeschriftungX.Content = "X";
            regBeschriftungY.Content = "Y";
        }

 
        private void plotLine (lineParameters res, double maxX, double step, string legend) {
            List<Double> xPoints=new List<Double>();
            List<Double> yPoints=new List<Double>();

            double y = 0, x=0;

            while (x < maxX)
            {
                y = res.K * x + res.D;
                xPoints.Add(x);
                yPoints.Add(y);

                x += step;
            }


            graphColour(xPoints, yPoints,new Pen(Brushes.IndianRed,1),new CirclePointMarker { Size = 0.0, Fill = Brushes.Black },legend);
        }

         
        private void plotCertainLine (lineParameters res, double maxX, double step, string legend, Pen pen) {
            List<Double> xPoints=new List<Double>();
            List<Double> yPoints=new List<Double>();

            double y = 0, x=0;

            while (x < maxX)
            {
                y = res.K * x + res.D;
                xPoints.Add(x);
                yPoints.Add(y);

                x += step;
            }


            graphColour(xPoints, yPoints,pen,new CirclePointMarker { Size = 0.0, Fill = Brushes.Black },legend);
        }

        /**
         * Removes the Lines and Scatters, which are already plotted.
         * 
         * 
         */
        private void clearRegressionLines()
        {
            Collection<IPlotterElement>  clearList = new Collection<IPlotterElement>();
            foreach (var x in regPlotter.Children)
            {
                if (x is LineGraph || x is ElementMarkerPointsGraph || x is MarkerPointsGraph)
                    clearList.Add(x);
            }

            foreach (IPlotterElement x in clearList)
            {
                regPlotter.Children.Remove(x);
            }
        }

        
    }
}
