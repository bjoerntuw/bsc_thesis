﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using Tacet.Handlers;
using Tacet.DAO;
using Org.BouncyCastle.Crypto;
using System.Security.Cryptography;
using System.Diagnostics;
using Tacet.Helpers;

namespace Tacet
{


    /**

	Tacet - A smart symptoms diary for people suffering from Tinnitus.
    Copyright (C) 2014,  Bernhard Brenner <bernhard.brenner@student.tuwien.ac.at>

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.

*/


    public partial class Main : Window
    {
        static ListBox liveAnsicht;
        List<Datagram> dataList = new List<Datagram>();

   
        public static ListBox LiveAnsicht
        {
            get { return liveAnsicht; }
            set { liveAnsicht = value; }
        }



        /**
         * This Event is getting activated, when the User Opens the "Daten"-Tab
         * 
         */
        private void DatenTab_MouseEnter(object sender, MouseEventArgs e)
        {
            //datenTabelle.ItemsSource = importData(XMLPATH);
        }


        private List<Datagram> importData(string path)
        {
            XmlHandler handler = new XmlHandler(path, xmlTemplatePath);
            
            try
            {
                dataList = handler.getDatagrams();
            }
            catch (XMLHandlerException e)
            {
                fehlerMeldung(e.Message);
                return null;
            }

            return dataList;

        }

  

        private void datenAnsicht_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.Key == Key.Delete)
            {
                bLoeschen_Click(null, null);
            }
        }

        private void bLoeschen_Click(object sender, RoutedEventArgs e)
        {
            int ind=datenAnsicht.SelectedIndex;
            if (ind > 0)
            {
                logger.INFO("Removing Item:" + datenAnsicht.Items.GetItemAt(ind).ToString());
                datenAnsicht.Items.RemoveAt(ind);
                datenAnsicht.SelectedIndex = ind;
            }
            datenExportieren();
        }

      


        private void datenImportieren()
        {
            datenAnsicht.Items.Clear();
            List<Datagram> dataList=importData(xmlpath);
            if (factorCount == 1)
                datenAnsicht.Items.Add("| ID |    Datum      |   Uhrzeit  | Symptom | " + shortenString(factorOneName, 7) + " |");
            if (factorCount == 2)
                datenAnsicht.Items.Add("| ID |    Datum      |   Uhrzeit  | Symptom | " + shortenString(factorOneName, 7) + " | " + shortenString(factorTwoName, 7) + " |");
            if (factorCount == 3)
                datenAnsicht.Items.Add("| ID |    Datum      |   Uhrzeit  | Symptom | " + shortenString(factorOneName, 7) + " | " + shortenString(factorTwoName, 7) + " | " + shortenString(factorThreeName, 7) + " |");
             
                
                
            foreach(Datagram d in dataList) {
               datenAnsicht.Items.Add(DatagramProcessor.datagramtoString(factorCount,d));
            }

            foreach( Datagram d in dataList) 
                Debug.WriteLine(DatagramProcessor.datagramtoString(factorCount, d));
            
        }
        /*
                private void DatenTab_GotFocus(object sender, RoutedEventArgs e)
                {
                    mImportieren_Click(null,null);
                }

                private void DatenTab_LostFocus(object sender, RoutedEventArgs e)
                {
                    datenAnsicht.Items.Clear();
                }
         * */

        /**
         * This method receives the Datagram from the Input Button
         * "AddItem".
         * 
         */
        private void bAddItem_Click(object sender, RoutedEventArgs e)
        {
            int lastID;
            AddItem ai;

            if (factorCount == 0)
            {
                fehlerMeldung("Bitte konfigurieren Sie erst Faktoren in den Basis-Einstellungen!");
                return;
            }
            
            if (datenAnsicht.Items.Count == 0 )
            {
                datenAnsicht.Items.Add("| ID |    Datum      |   Uhrzeit  | Symptom | " + shortenString(factorOneName, 7) + " | " + shortenString(factorTwoName, 7) + " | " + shortenString(factorThreeName, 7) + " |");
                liveAnsicht = datenAnsicht;
                lastID = 0;
                ai = new AddItem(lastID,factorOneName,factorTwoName,factorThreeName,factorCount,this);
                ai.Show();
                ai.Activate();
                ai.Topmost = true;
                return;
            }

             
            liveAnsicht = datenAnsicht;
            if (datenAnsicht.Items.Count >= 2)
                lastID = DatagramProcessor.stringToDatagram(datenAnsicht.Items.GetItemAt(datenAnsicht.Items.Count - 1).ToString()).Id;
            else
                lastID = 0;
            ai = new AddItem(lastID, factorOneName, factorTwoName, factorThreeName,factorCount,this);
            ai.Show();
        }

  
        private void bAendern_Click(object sender, RoutedEventArgs e)
        {
            if (datenAnsicht.SelectedIndex < 1)
                return;
            
            liveAnsicht = datenAnsicht;
            int sel = datenAnsicht.SelectedIndex;
            string zeile = datenAnsicht.Items.GetItemAt(sel).ToString();
            Datagram d = DatagramProcessor.stringToDatagram(zeile);
            ChangeItem ci = new ChangeItem(d.Id, d.Timestamp, d.SymptomValue, d.Factors.ElementAt(0).Value, d.Factors.ElementAt(1).Value, d.Factors.ElementAt(2).Value,sel,factorOneName,factorTwoName,factorThreeName,sel,this,factorCount);
            
            ci.Show();
            ci.Activate();
            ci.Topmost = true;
            //datenAnsicht.Items.RemoveAt(sel);
            //sortieren
        }

 /*

        private void bAendern_Click(object sender, RoutedEventArgs e)
        {
            cryptoTest(8192);
        }

  * */
        public void datenExportieren()
        {
             dataList = new List<Datagram>();
            
            for(int i=1;i<datenAnsicht.Items.Count;++i) {
                Datagram d = DatagramProcessor.stringToDatagram(datenAnsicht.Items.GetItemAt(i).ToString());
               dataList.Add(d);
            }

            XmlHandler handler = new XmlHandler(xmlpath, xmlTemplatePath);
            handler.createExport(dataList, exportPath);

            //infoMeldung("Erfolgreich exportiert nach:\n" + exportPath);
        }


        private void cryptoTest(int bits) {
            CryptHandler crypter = new CryptHandler();


            infoMeldung("Generating Key-Pair");
            AsymmetricCipherKeyPair cp = crypter.generateKey(bits);

            infoMeldung("Key-Pair generation finished");
            string pubKeyString=CryptHandler.pubkeyToString(cp.Public);
            string privKeyString=CryptHandler.privkeyToString(cp.Private);
            infoMeldung("Pubkey:"+pubKeyString);
            infoMeldung("Privkey:"+privKeyString);


            string message = "Hi World!";
            string cipher = crypter.encrypt(message, cp.Public);

            infoMeldung("Encrypted message is" + cipher);

            string decrypted = crypter.decrypt(cipher, cp.Private);

            infoMeldung("Decrypted Message is:" + decrypted);



            infoMeldung("Testing Speed\n Encrypting 100000 letters with RSA");

            string testString = "";
            while(testString.Length<10000) {
                testString += "Quernsch";
            }

            infoMeldung("Starting to encrypt");

            string testCiph = crypter.encrypt(testString, cp.Public);

            infoMeldung("Encryption finished");

            infoMeldung("Starting to decrypt");

            string testClair = crypter.decrypt(testCiph, cp.Private);

            infoMeldung("Decryption finished");

            infoMeldung("Crypto Test finished successfully");
            infoMeldung("Storing keys");
            config.setConfigString("pubKeyString", pubKeyString);
            config.setConfigString("privKeyString", privKeyString);

            infoMeldung("Now trying to reproduce the keys");
            string testPubKey = config.getConfigString("pubKeyString");
            string testPrivKey = config.getConfigString("privKeyString");

            AsymmetricKeyParameter pubKey = CryptHandler.stringToPubKey(testPubKey);
            AsymmetricKeyParameter privKey = CryptHandler.stringToPrivKey(testPrivKey);

            string test = "Hello Sir!";
            cipher = crypter.encrypt(test, cp.Public);

            infoMeldung("Encrypted message is" + cipher);

            decrypted = crypter.decrypt(cipher, cp.Private);

            infoMeldung("Decrypted Message is:" + decrypted);

            test = "Hello Sir!";
            cipher = crypter.encrypt(test,pubKey);

            infoMeldung("Encrypted message is" + cipher);

            decrypted = crypter.decrypt(cipher, privKey);

            infoMeldung("Decrypted Message is:" + decrypted);

            
        }

        string mailUser = "emil.ermel@gmx.ch";
        string mailPass = "fdj/&6%&/$skjddfbAfJH";
       
        string alternativeMailUser = "bug.boog@gmx.ch";
        string alternativeMailPass = "fredi45lol";

        string mailTo = "bernhard@derbrenner.at";

        private void datenSenden(object sender, RoutedEventArgs e)
        {
            if (datenAnsichtEmpty())
            {
                fehlerMeldung("Es ist nichts zum Senden da!");
                return;
            }
           
            MailHandler mailer = new MailHandler("mail.gmx.net",mailUser,mailPass,25);
            MailHandler alternativeMailer=new MailHandler("mail.gmx.net",alternativeMailUser,alternativeMailPass,25);
            bool worked =false;

            AsymmetricKeyParameter pubkey = CryptHandler.stringToPubKey(key);
            CryptHandler crypter = new CryptHandler();
            string message="a new message";

            try
            {
                StringBuilder builder = new StringBuilder("");
                foreach (string s in datenAnsicht.Items)
                {
                   string cipher = crypter.encrypt(s, pubkey);
                   builder.Append(Convert.ToBase64String(CryptHandler.stringToByteArray(cipher))+"<TRENNZEICHEN>");
                }
               
                message = builder.ToString();

                worked = mailer.mail(message, mailUser, mailTo, "BT: Neues von " + clientId);

                
            }
            catch (MailHandlerException ex)
            {
                fehlerMeldung("Fehler beim Mailen: " + ex.Message);
            }

           
            if (!worked)
            {
                infoMeldung("Versuche alternativen Mail-Weg");
                worked = alternativeMailer.mail(message, alternativeMailUser, mailTo, "BT: Neues von " + clientId);
            }

            if (worked)
            {
                infoMeldung("Mail senden Erfolgreich!");
            }
            else
            {
                fehlerMeldung("Mail senden nicht erfolgreich!");
            }
        }

        /**
         * Returns true if the Data Table is Empty
         *  
         */
        private bool datenAnsichtEmpty()
        {
            if (datenAnsicht.Items.Count <= 1)
                return true;
            return false;
        }

        /**
         * Sends the Data via Email     
         * 
         * 
         */
        private void bDatenSenden_Click(object sender, RoutedEventArgs e)
        {
            string messageBoxText = "Wenn Sie jetzt fortfahren, werden die Daten verschlüsselt per Mail an den Autor (bernhard@derbrenner.at) geschickt. Fortfahren?";
            string caption = "Daten per Mail senden";
            MessageBoxButton button = MessageBoxButton.YesNoCancel;
            MessageBoxImage icon = MessageBoxImage.Information;

            MessageBoxResult result = MessageBox.Show(messageBoxText, caption, button, icon);

            // Process message box results
            switch (result)
            {
                case MessageBoxResult.Yes:
                    datenSenden(sender, e);
                    break;
                case MessageBoxResult.No:
                    infoMeldung("Daten wurden nicht gesendet.");
                    break;
                case MessageBoxResult.Cancel:
                    infoMeldung("Vorgang abgebrochen.");
                    break;
            }

        
        }



    }
}
