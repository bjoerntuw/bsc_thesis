﻿WPF Dynamic Data Display is a library of WPF controls for dynamic data visualization.

Homepage - http://www.codeplex.com/dynamicdatadisplay/
Blog - http://microsoft.cs.msu.su/Blog/thecentury/default.aspx (mostly in Russian for now)
Twitter - https://twitter.com/DynamicDataDisp