﻿using CryptExpert.Handlers;
using Org.BouncyCastle.Crypto;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace CryptExpert
{
    /// <summary>
    /// Interaktionslogik für MedBlockDecipherer.xaml
    /// </summary>
    public partial class MedBlockDecipherer : Window
    {
        public MedBlockDecipherer()
        {
            InitializeComponent();
        }

        private void fehlerMeldungNL(string text)
        {
            System.Windows.MessageBox.Show(text);
        }

        private void buttonDecrypt_Click(object sender, RoutedEventArgs e)
        {
            string cipherText = tbEingabeMBD.Text;
            List<String> blockList = new List<String>();
            blockList = Regex.Split(cipherText,"<TRENNZEICHEN>").ToList<String>();



            foreach (string s in blockList)
            {
                string z = s.Trim();
                string clairBlock = decryptBlockComplete(z, tbPrivKeyMBD.Text);
                lbAusgabeMBD.Items.Add(clairBlock);

            }
        }
        private string decryptBlockComplete(string block, string key)
        {
            if (block != "" && key != "")
            {
                CryptHandler handler = new CryptHandler();
                AsymmetricKeyParameter privKey = CryptHandler.stringToPrivKey(tbPrivKeyMBD.Text);


                string data = CryptHandler.byteArrayToString(Convert.FromBase64String(block));
                return handler.decryptBlock(data, privKey);
            }
            else
                return null;
        }


        /**
         * This method takes a List of the Datagram lines which are previously decrapted by the program.
         * Then it converts in to an XML Med-Data Style format.
         * Finally, it saves it to an XML-Document at the given path.
         */
        private void encodeClairToXMLDocument(string path)
        {
            XmlHandlerCE xmlce = new XmlHandlerCE();
            List<Datagram> dataList = new List<Datagram>();

            //i begins with 1 here, because the first line is the header line and does not have to be converted.
            for (int i = 1; i < lbAusgabeMBD.Items.Count; ++i)
            {
                string s = "";
                try
                {
                     s = lbAusgabeMBD.Items.GetItemAt(i).ToString().Trim();
                }
                catch (NullReferenceException)
                {
                    //hat eine leere Zeile erwischt
                    continue;
                }
                if (s.Equals(""))
                    continue;
                Datagram d = Datagram.getDatagramFromLine(s);

                dataList.Add(d);
            }

            xmlce.datenExportieren(dataList, path);

        }

        private void buttonEncode_Click(object sender, RoutedEventArgs e)
        {
            encodeClairToXMLDocument(tbPfadMBD.Text);

        }

        private void TextBox_TextChanged_1(object sender, TextChangedEventArgs e)
        {

        }
 
    }
}
