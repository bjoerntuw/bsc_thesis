﻿using CryptExpert.DAO;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Xml;

namespace CryptExpert.Handlers
{
    /**
     * XMLHandlerCE is a distribution of the original XMLHandler made for Tacet.
     * It is a reduced version, so that logging and other functionalities where thrown out to make it more lightweight.
     *  To say it short, it is reduced to the functionality of exporting xml data.
     */
    class XmlHandlerCE
    {

        private const string XMLTEMPLATEPATH = "template.xml";

        /**Same es createExportOfThisDocument, but takes a list of datagrams instead of 
       * exporting the local stored Document object.
       * 
       * @param dList The Datagram List to be exported. 
       * @param path This is the export destination. 
       */

        public void createExport(List<Datagram> dList, string path)
        {
            XmlDocument exportDoc = new XmlDocument();
            exportDoc.Load(XMLTEMPLATEPATH);

            foreach (Datagram d in dList)
            {
                addDatagramToDocument(d, exportDoc);
            }

            exportDoc.Save(path);
        }

         /**
         * Fügt ein neues Datagramm zu dem übergebenen XML Dokument hinzu.
         * 
         * 
         * @param d  Das Datagramm, bereits mit Daten befüllt.
         * 
         */
        public void addDatagramToDocument(Datagram d, XmlDocument docum)
        {
            if (d == null)
            {
                fehlerMeldungNL("Error adding Datagram to Document: Document not initialised");            
            }

            XmlElement datagramElement = docum.CreateElement("Datagram");
            datagramElement.SetAttribute("id", "" + d.Id);
            datagramElement.SetAttribute("timestamp", "" + d.Timestamp);
            datagramElement.SetAttribute("symptomValue", "" + d.SymptomValue);

            List<XmlElement> factorElements = new List<XmlElement>();

            foreach (Factor f in d.Factors)
            {
                XmlElement el = docum.CreateElement("factor");
                el.SetAttribute("fid", "" + f.Fid);
                el.SetAttribute("value", "" + f.Value);
                datagramElement.AppendChild(el);
            }


            try
            {
                docum.DocumentElement.AppendChild(datagramElement);
            }
            catch (Exception allgEx)
            {
                fehlerMeldungNL("Error writing Datagram into Document:" + allgEx.Message);
            }

        }


        public void datenExportieren(List <Datagram> dataList, string exportPath)
        {
                 createExport(dataList, exportPath);
            //An abuse of the fehlermeldung as an infomeldung. Sorry for that.
                 fehlerMeldungNL("Erfolgreich exportiert nach:\n" + exportPath);
        }

        private void fehlerMeldungNL(string text)
        {
            System.Windows.MessageBox.Show(text);
        }
        
    }
}
