﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace CryptExpert
{
    class CryptHandlerException : Exception
    {
        private string p;

        public CryptHandlerException(string p)
        {
            // TODO: Complete member initialization
            this.p = p;
        }

        public string getMessage()
        {
            return this.p;
        }
    }
}
