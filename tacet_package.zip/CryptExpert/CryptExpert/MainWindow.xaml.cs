﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using Org.BouncyCastle.Crypto;
using System.Windows.Forms;

namespace CryptExpert
{
    /// <summary>
    /// Interaktionslogik für MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        System.IO.StreamReader reader;
        System.IO.StreamWriter writer;

        private void initializeFileIO(string inputPath, string outputPath)
        {
            reader = new System.IO.StreamReader(inputPath);
            writer = new System.IO.StreamWriter(outputPath);
        }

        private void endFileIO(string inputPath, string outputPath)
        {
            reader.Close();
            writer.Close();
        }
        public MainWindow()
        {
            InitializeComponent();

        }

        private string readFile(string path)
        {
            StringBuilder text = new StringBuilder("");
            if ((text.Append(reader.ReadLine())) != null)
                return text.ToString();
            else
                return "";
        }

        private void writeFile(string text, string path)
        {

            writer.Write(text);

        }


        /**
         * There is an easter-egg:
         * If you type a certain magic word and click "encrypt", then the medical data Block decipherer opens up!
         * 
         */
        private void buttonEncrypt_Click(object sender, RoutedEventArgs e)
        {
            if(tbEingabe.Text.Equals("s98gHI79d9e")) {
                MedBlockDecipherer mbd = new MedBlockDecipherer();
                mbd.Show();
                mbd.Activate();
                mbd.Topmost = true;
                return;
            }

            if (tbPubKey.Text != "" && tbEingabe.Text != "")
            {
                tbAusgabe.Text = "";

                int keylength = 1024;
                try
                {
                    keylength = Convert.ToInt32(tbBit.Text);
                }
                catch (Exception)
                {
                    ;//nothing to do
                }
                int blocksize = keylength / 1024 * 120;

                CryptHandler handler = new CryptHandler();
                AsymmetricKeyParameter pubKey = null;
                try
                {
                    pubKey = CryptHandler.stringToPubKey(tbPubKey.Text);
                }
                catch (CryptHandlerException ex)
                {
                    fehlerMeldungNL(ex.getMessage());
                }
                if (tbEingabe.Text.Length > blocksize)
                {
                    tbEingabe.Text = tbEingabe.Text.Substring(0, blocksize);
                }

                string data = tbEingabe.Text;
                tbAusgabe.Text = Convert.ToBase64String(CryptHandler.stringToByteArray(handler.encryptBlock(data, pubKey)));
            }
        }

        private void buttonDecrypt_Click(object sender, RoutedEventArgs e)
        {
            if (tbPrivKey.Text != "" && tbEingabe.Text != "")
            {
                CryptHandler handler = new CryptHandler();
                AsymmetricKeyParameter privKey = CryptHandler.stringToPrivKey(tbPrivKey.Text);


                string data = CryptHandler.byteArrayToString(Convert.FromBase64String(tbEingabe.Text));
                tbAusgabe.Text = handler.decryptBlock(data, privKey);
            }
        }

        private void bGenerate_Click(object sender, RoutedEventArgs e)
        {
            if (tbBit.Text.Equals(""))
                return;
            int bits = Convert.ToInt32(tbBit.Text);
            if (bits >= 1024 && bits <= 32768)
            {
                CryptHandler handler = new CryptHandler();
                AsymmetricCipherKeyPair cp = handler.generateKey(bits);

                tbPubKey.Text = CryptHandler.pubkeyToString(cp.Public);
                tbPrivKey.Text = CryptHandler.privkeyToString(cp.Private);


            }
        }

        
        private void fehlerMeldungNL(string text)
        {
            System.Windows.MessageBox.Show(text);
        }
        

    }
    }


