﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace CryptExpert.DAO
{
    class Factor
    {
            private int fid = 0;

            public int Fid
            {
                get { return fid; }
                set { fid = value; }
            }
            private double value = 0;

            public double Value
            {
                get { return this.value; }
                set { this.value = value; }
            }


            public Factor(int fid, double value)
            {
                this.fid = fid;
                this.value = value;
            }
   }
}

